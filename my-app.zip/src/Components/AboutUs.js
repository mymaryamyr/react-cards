import React from 'react';

function AboutUs() {
    return (
        <div>
            <h2>About</h2>
            <p>hfbuhvcbdslnfcuwfhqeubhewfnlwenkjd</p>
        </div>
    )

}

export default AboutUs;