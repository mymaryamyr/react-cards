import React from 'react';
import list from '../data.json'
import ProductList from './ProductList';


export default () => <ProductList list={list} />
