import React from 'react';  
import { Route } from 'react-router-dom';  

const LayoutLanding = ({ children }) => {
  return (
    <div>
      {children}
    </div>
  );
}

  
  
export default LayoutLanding; 