import React, {Component} from 'react';

function Err404  () {
    return (
        <div>
            <h1>PAGE NOT FOUND</h1>
        </div>
    )

}


export default Err404;