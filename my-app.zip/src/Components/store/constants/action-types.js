export const ADD_ITEM = "ADD_ITEM"

export const INCREMENT = "INCREMENT"

export const REMOVE_ITEM = "REMOVE_ITEM"

export const EMPTY_BASKET = "EMPTY_BASKET"

export const ADD_DISCOUNT = "ADD_DISCOUNT"

export const CALC_FINAL = "CALC_FINAL"


