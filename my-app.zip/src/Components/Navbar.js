import React from 'react';
import s from '../CSS.module/Navbar.module.css'

function Navbar (props) {
    return (
        <ul className={s.navbar}>
            {props.children}
        </ul>
    )
}
export default Navbar;