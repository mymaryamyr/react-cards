import React, {Component} from 'react';
import style from '../CSS.module/Card.module.css';


class SingleData extends Component {
    render() {
        return (
            <p>Something</p>
        )
    }
}

export default SingleData;